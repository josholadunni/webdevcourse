import express from "express";
import bodyParser from "body-parser";
import pg from "pg";

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "world",
  password: "hpharrypot",
  port: 5432,
});

db.connect();

app.get("/", async (req, res) => {
  try {
    const result = await db.query("SELECT * FROM public.visited_countries");

    // console.log(result);

    const data = {
      total: result.rows.length,
      countries: result.rows.map((row) => {
        return row.country_code;
      }),
    };

    console.log(data);

    res.render("index.ejs", data);
  } catch (err) {
    console.error(err);
    res.status(500).send("An error occured");
  }
});

app.post("/add", async (req, res) => {
  let countryName = req.body.country;

  //Convert country name into words
  let countryNameWords = countryName.split(" ");
  countryNameWords = countryNameWords.map((word) => {
    return word[0].toUpperCase() + word.substr(1);
  });

  countryNameWords = countryNameWords.join(" ");

  countryName = countryNameWords;

  try {
    const result = await db.query("SELECT * FROM public.countries");

    // console.log(result);

    result.rows.map(async (row) => {
      if (row.country_name == countryName) {
        await db.query(
          "INSERT INTO public.visited_countries (country_code) VALUES ($1)",
          [row.country_code]
        );
        console.log("Inserted country code");
      } else {
        console.log(`Didnt insert country code ${row.country_code}`);
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).send("An error occurred");
  }

  res.redirect("/");
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
